// IIFE - To avoid flash of default theme: light
(function () {
  document.documentElement.classList.add('dark');
})();
