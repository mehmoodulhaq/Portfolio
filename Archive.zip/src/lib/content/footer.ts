import { FooterSectionType } from '@/lib/types/sections';

export const footerSection: FooterSectionType = {
    title: '',
    link: 'https://github.com/vatsalsinghkv/portfolio-website',
};
